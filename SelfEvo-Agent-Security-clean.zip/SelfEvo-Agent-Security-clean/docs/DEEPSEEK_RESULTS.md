# DeepSeek Raw Result Files

This package keeps DeepSeek raw evidence files with the same structure as `results/openai/`.

## File Mapping

| Policy | run_id | Report | Metadata |
| --- | --- | --- | --- |
| baseline | `run_20260704_002917_536a50` | `results/deepseek/deepseek_baseline_attack_case_results.md` | `results/deepseek/deepseek_baseline_run_metadata.json` |
| dry_run | `run_20260704_003015_abecce` | `results/deepseek/deepseek_dry_run_attack_case_results.md` | `results/deepseek/deepseek_dry_run_run_metadata.json` |

## Notes

- DeepSeek and OpenAI use the same four safety-simulation attack cases.
- `baseline` records the no-defense control path as `simulated_executed=true` and demo-visible effects. It does not execute real commands.
- `dry_run` records and blocks high-risk tool-call intent through the policy layer.
- `execute_command` never creates a real process and never modifies the real system state in any run.
