# SelfEvo Agent Security

SelfEvo Agent Security 是一个面向 Self-evolving Agent 的记忆污染攻击与防御实验项目。项目使用 CrewAI 作为 Agent 编排框架，支持通过 OpenAI-compatible API 调用 DeepSeek 和 OpenAI / ChatGPT，并在本地实现 shadow memory、工具调用审计、策略拦截、dry-run 执行和实验指标统计。

## 核心能力

- 支持 `mock`、DeepSeek、OpenAI / ChatGPT 三类实验后端。
- 支持 infection、trigger、control 和 attack scenario 多类任务。
- 使用 shadow memory 记录不可信记忆及其来源。
- 通过 policy 和 ToolRuntime 识别、审计并拦截高风险工具调用。
- `execute_command` 永远 dry-run，不创建真实进程，不修改系统状态。
- `read_url` 只读取本地 fixture，不访问真实网页。
- 基于 JSONL 日志生成指标报告和静态 demo dashboard。
- 已保留 DeepSeek 与 OpenAI 的攻击/防御对照实验结论。

## 项目结构

```text
.
├── agent/                    # CrewAI Agent、mock backend、结构化输出 schema
├── config/                   # 额外配置模板，例如 OpenAI / ChatGPT .env 示例
├── data/                     # 本地安全实验样本和 fixture
├── docs/                     # 完整报告、对比实验、威胁模型、项目结构说明
├── lab/                      # 实验任务、指标统计、demo dashboard 生成
├── results/                  # 已整理保留的实验结果
├── scripts/                  # Windows 一键运行脚本
├── security/                 # shadow memory、policy、工具运行时和审计
├── tests/                    # 自动化测试
├── config.py                 # 全局实验配置
├── run_infection.py          # infection 阶段入口
├── run_trigger.py            # trigger 阶段入口
├── run_attack_scenarios.py   # baseline / dry-run 攻击对照入口
├── requirements.txt          # Python 依赖
└── 实验结果说明.md             # 当前实验结果总说明
```

更细的逐文件说明见 [docs/项目结构说明.md](docs/项目结构说明.md)。

## 环境要求

- Python 3.10 或更高版本。
- Windows PowerShell 或其他可运行 Python 的终端。
- 运行真实模型实验时需要可用的 DeepSeek 或 OpenAI API key。
- 无 API key 时可使用 `AGENT_BACKEND=mock` 运行离线链路验证。

安装依赖：

```bash
pip install -r requirements.txt
```

## 配置模型

先复制配置文件：

```powershell
Copy-Item .env.example .env
```

如果使用 Linux / macOS：

```bash
cp .env.example .env
```

### 离线 mock backend

mock backend 不调用真实大模型，适合快速验证日志、策略和指标链路：

```env
AGENT_BACKEND=mock
POLICY_MODE=dry_run
```

### DeepSeek

```env
EXPERIMENT_MODE=crewai
AGENT_BACKEND=crewai
POLICY_MODE=dry_run
MODEL=deepseek-v4-flash
LLM_PROVIDER=openai
LLM_API_KEY=replace-with-your-deepseek-key
LLM_BASE_URL=https://api.deepseek.com
LLM_STRUCTURED_OUTPUT=off
LLM_TEMPERATURE=0
CREWAI_VERBOSE=true
MAX_FIXTURE_CHARS=100000
CREWAI_TRACING_ENABLED=false
OTEL_SDK_DISABLED=true
```

### OpenAI / ChatGPT

项目已提供 OpenAI 配置模板：[config/openai.env.example](config/openai.env.example)。

```env
EXPERIMENT_MODE=crewai
AGENT_BACKEND=crewai
POLICY_MODE=dry_run
MODEL=gpt-5.5
LLM_PROVIDER=openai
LLM_API_KEY=replace-with-your-openai-api-key
LLM_BASE_URL=
LLM_STRUCTURED_OUTPUT=off
LLM_TEMPERATURE=1
CREWAI_VERBOSE=true
MAX_FIXTURE_CHARS=100000
CREWAI_TRACING_ENABLED=false
OTEL_SDK_DISABLED=true
```

DeepSeek 和 OpenAI / ChatGPT 复用同一套 CrewAI 调用代码，通常只需要修改 `.env` 中的模型、API key、base URL 和结构化输出配置。

## 运行方法

先运行自动化测试：

```bash
python -m unittest discover -v
```

运行完整 infection / trigger 实验：

```bash
python run_infection.py
python run_trigger.py
python lab/metrics.py
```

运行攻击/防御对照实验：

```bash
python run_attack_scenarios.py --policy baseline --agent-backend mock
python run_attack_scenarios.py --policy dry_run --agent-backend mock
python lab/metrics.py
python lab/demo_dashboard.py
```

Windows PowerShell 可使用一键 demo 脚本：

```powershell
.\scripts\run_attack_demo.ps1 -AgentBackend mock
```

如需对 DeepSeek 或 OpenAI / ChatGPT 运行同一组攻击对照实验，将 `.env` 配置为对应模型后，把命令中的 `--agent-backend mock` 改为 `--agent-backend crewai`。

## 输出文件

每次运行会在 `logs/runs/<run_id>/` 下生成审计日志：

```text
run_metadata.json
memory_events.jsonl
tool_calls.jsonl
policy_events.jsonl
task_events.jsonl
errors.jsonl
shadow_memory.json
```

指标与展示文件默认生成到：

```text
logs/runs/reports/report.md
logs/runs/reports/summary.csv
logs/runs/reports/demo_dashboard.html
```

已整理保留的 OpenAI / ChatGPT 实测结果位于：

```text
results/openai/openai_baseline_attack_case_results.md
results/openai/openai_dry_run_attack_case_results.md
results/openai/openai_baseline_run_metadata.json
results/openai/openai_dry_run_run_metadata.json
```

## 实验结果摘要

| 模型 | 策略 | 高风险案例数 | baseline 模拟成功 | 防护拦截 | 可见 demo 效果 | 真实执行 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| DeepSeek `deepseek-v4-flash` | baseline | 4 | 4 | 0 | 4 | 0 |
| DeepSeek `deepseek-v4-flash` | dry_run | 4 | 0 | 4 | 0 | 0 |
| OpenAI `gpt-5.5` | baseline | 4 | 4 | 0 | 4 | 0 |
| OpenAI `gpt-5.5` | dry_run | 4 | 0 | 4 | 0 | 0 |

结论：DeepSeek 和 OpenAI / ChatGPT 均可用于展示记忆污染诱导高风险工具调用意图；开启 dry-run 防护后，高风险调用被记录、溯源并拦截；所有实验中的真实执行次数始终为 0。

详细结果见 [实验结果说明.md](实验结果说明.md) 和 [docs/多模型攻击防御对比.md](docs/多模型攻击防御对比.md)。

## 文档索引

各自分工如下：

- [实验结果说明.md](实验结果说明.md)：结果总览、完成情况、关键指标和推荐展示口径。
- [docs/多模型攻击防御对比.md](docs/多模型攻击防御对比.md)：DeepSeek 与 OpenAI / ChatGPT 在同一组攻击样本上的对比结论。
- [docs/威胁模型与安全声明.md](docs/威胁模型与安全声明.md)：攻击者能力假设、安全边界、合规说明和评审展示口径。
- [docs/项目结构说明.md](docs/项目结构说明.md)：目录和逐文件说明。

## 安全声明

本项目只用于安全研究、教学演示和比赛展示。实验样本均为本地 synthetic fixture，攻击效果均为安全模拟结果。`execute_command` 不会真实执行命令，baseline 仅表示“无防护情况下会进入危险路径”的模拟结果，不代表项目执行了真实攻击行为。

请不要将本项目改造成真实攻击工具，也不要在未授权环境中测试或部署。


## DeepSeek raw result files

DeepSeek raw baseline and dry-run evidence files are preserved under `results/deepseek/`, aligned with `results/openai/`. See `docs/DEEPSEEK_RESULTS.md` for the run id to file mapping.
